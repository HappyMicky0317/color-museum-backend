export const DB_URI = process.env.DB_URI;
export const PROVIDER = process.env.PROVIDER;
export const CLONE_X_ADDRESS = "0x49cF6f5d44E70224e2E23fDcdd2C053F30aDA28B";
export const DOODLES_ADDRESS = '0x8a90CAb2b38dba80c64b7734e58Ee1dB38B8992e';